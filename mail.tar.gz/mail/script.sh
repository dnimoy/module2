#!/bin/bash

# Проверка входных параметров
if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Использование: $0 <Фамилия_студента> <Домен>"
  echo "Пример: $0 Иванов example.com"
  exit 1
fi

STUDENT=$1
DOMAIN=$2
IMG_DIR="./img"
TXT_DIR="./txt"
PDF_DIR="./pdf"

# Создаем тестовые файлы
echo "Создание тестовых файлов..."
dd if=/dev/urandom of="$TXT_DIR/large_text_$STUDENT.txt" bs=700K count=1  # 700KB
dd if=/dev/zero of="$PDF_DIR/medium_$STUDENT.pdf" bs=500K count=1  # 500KB
sleep 1

echo "=== Начало тестов для студента $STUDENT в домене $DOMAIN ==="

# 1. Успешная доставка простого письма
echo "Test 1 [$STUDENT]: Success mail without attachment" | mail -s "Success mail [$STUDENT]" mailuser@$DOMAIN
echo "Test 1 [$STUDENT]: Success mail without attachment" | mail -s "Success mail [$STUDENT]" ubuntu@$DOMAIN
echo "Тест 1 завершен. Ожидание 5 секунд..."
sleep 5

# 2. Письма с разрешенными вложениями
echo "Test 2 [$STUDENT]: Mail with image 53КБ" | mail -s "Small image for [$STUDENT]" -A "$IMG_DIR/img1.png" mailuser@$DOMAIN
sleep 2
echo "Test 2 [$STUDENT]: Mail with text file" | mail -s "Text doc for [$STUDENT]" -A "$TXT_DIR/text1.txt" ubuntu@$DOMAIN
sleep 2
echo "Test 2 [$STUDENT]: Mail with pdf-file" | mail -s "PDF file for [$STUDENT]" -A "$PDF_DIR/pdf_file2.pdf" ubuntu@$DOMAIN
echo "Тест 2 завершен. Ожидание 5 секунд..."
sleep 5

# 3. Письмо с вложением, превышающим message_size_limit (ожидаем ошибку 552)
echo "Test 3 [$STUDENT]: Mail with PDF 680КБ" | mail -s "Letter size exceeded [$STUDENT]" -A "$PDF_DIR/pdf_file1.pdf" mailuser@$DOMAIN
echo "Тест 3 завершен. Ожидание 5 секунд..."
sleep 5

# 4. Письмо с двумя получателями (ожидаем ошибку из-за smtpd_recipient_limit=1)
echo "Test 4 [$STUDENT]: Two recipients" | mail -s "Recipient limit violation [$STUDENT]" mailuser@$DOMAIN,ubuntu@$DOMAIN
echo "Тест 4 завершен. Ожидание 5 секунд..."
sleep 5

# 5. Серия писем для заполнения почтового ящика (используем файл 500KB)
for i in {1..5}; do
  echo "Test 5.$i [$STUDENT]: Filling the mailbox" | mail -s "Mail $i [$STUDENT]" -A "$PDF_DIR/medium_$STUDENT.pdf" ubuntu@$DOMAIN
  sleep 1
done
echo "Тест 5 завершен. Ожидание 5 секунд..."
sleep 5

# 6. Письмо с несуществующим получателем (ожидаем ошибку 550)
echo "Test 6 [$STUDENT]: Non-existent address" | mail -s "Incorrect address [$STUDENT]" nonexistent_$STUDENT@$DOMAIN
echo "Тест 6 завершен. Ожидание 5 секунд..."
sleep 5

# 7. Письмо с HTML-разметкой
echo "<html><body><h1>HTML-mail [$STUDENT]</h1><p>Test formatting</p></body></html>" | mail -s "HTML-mail [$STUDENT]" -a "Content-Type: text/html" mailuser@$DOMAIN
echo "Тест 7 завершен. Ожидание 5 секунд..."
sleep 5

# 8. Письмо с большим текстовым вложением (700KB)
echo "Test 8 [$STUDENT]: Large text file" | mail -s "Size check [$STUDENT]" -A "$TXT_DIR/large_text_$STUDENT.txt" ubuntu@$DOMAIN
echo "Тест 8 завершен. Ожидание 5 секунд..."
sleep 5

echo "=== Все тесты для студента $STUDENT в домене $DOMAIN завершены ==="
